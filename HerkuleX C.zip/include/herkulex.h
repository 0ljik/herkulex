﻿#ifndef HERKULEX_H_
#define HERKULEX_H_

//////////////////////////////프로토콜에 대한 선언//////////////////////////////
//각 항목의 인덱스
#define PROTOCOL_SIZE_IDX					2
#define PROTOCOL_ID_IDX						3
#define PROTOCOL_CMD_IDX					4
#define PROTOCOL_CS1_IDX					5
#define PROTOCOL_CS2_IDX					6
#define PROTOCOL_DATA_IDX					7

//헤더 관련
#define HEADER								0xFF

//SIZE 관련
#define MIN_PACKET_SIZE						7
#define MIN_ACK_PACKET_SIZE					9
#define MAX_PACKET_SIZE						223
#define MAX_DATA_SIZE						(MAX_PACKET_SIZE-MIN_PACKET_SIZE)

//ID 관련
#define MAX_ID								0xFD    
#define BROADCAST_ID						0xFE  

//CMD 관련 - Request Packet
#define CMD_EEP_WRITE						0x01
#define CMD_EEP_READ						0x02
#define CMD_RAM_WRITE						0x03
#define CMD_RAM_READ						0x04    
	#define CMD_RW_DATA_ADDR_IDX			7
	#define CMD_RW_DATA_LEN_IDX				8
#define CMD_I_JOG							0x05
	#define CMD_I_JOG_STRUCT_SIZE			5
	#define CMD_I_JOG_MAX_DRS				(MAX_DATA_SIZE/CMD_I_JOG_STRUCT_SIZE)
#define CMD_S_JOG							0x06
	#define CMD_S_JOG_STRUCT_SIZE			4
	#define CMD_S_JOG_MAX_DRS				(MAX_DATA_SIZE/CMD_S_JOG_STRUCT_SIZE)
#define CMD_STAT							0x07    
#define CMD_ROLLBACK						0x08
#define CMD_REBOOT							0x09

#define CMD_MIN								(CMD_EEP_WRITE)
#define CMD_MAX								(CMD_REBOOT)

//CMD 관련 - ACK Packet
#define CMD_ACK_MASK						0x40

#define CMD_EEP_WRITE_ACK					(CMD_EEP_WRITE|CMD_ACK_MASK)
#define CMD_EEP_READ_ACK					(CMD_EEP_READ|CMD_ACK_MASK)
#define CMD_RAM_WRITE_ACK					(CMD_RAM_WRITE|CMD_ACK_MASK)
#define CMD_RAM_READ_ACK					(CMD_RAM_READ|CMD_ACK_MASK)
#define CMD_I_JOG_ACK						(CMD_I_JOG|CMD_ACK_MASK)
#define CMD_S_JOG_ACK						(CMD_S_JOG|CMD_ACK_MASK)
#define CMD_STAT_ACK						(CMD_STAT|CMD_ACK_MASK)
#define CMD_ROLLBACK_ACK					(CMD_ROLLBACK|CMD_ACK_MASK)
#define CMD_REBOOT_ACK						(CMD_REBOOT|CMD_ACK_MASK)

#define CMD_ACK_MIN							(CMD_EEP_WRITE_ACK)
#define CMD_ACK_MAX							(CMD_REBOOT_ACK)

//CheckSum 관련
#define CHKSUM_MASK							0xFE

//////////////////////////////프로토콜 구조체//////////////////////////////
typedef struct DrsJog
{
	unsigned int	uiValue : 15;
	unsigned int	reserved : 1;
}DrsJog;

typedef struct DrsSet
{
	unsigned char	ucStopFlag : 1;
	unsigned char	ucMode : 1;
	unsigned char	ucLedGreen : 1;
	unsigned char	ucLedBlue : 1;
	unsigned char	ucLedRed : 1;
	unsigned char	ucJogInvalid : 1;
	unsigned char	reserved : 2;
}DrsSet;

typedef struct DrsIJog 
{
	DrsJog			stJog;
	DrsSet			stSet;
	unsigned char	ucId;
	unsigned char	ucPlayTime;
}DrsIJog;

typedef struct DrsSJog 
{
	DrsJog			stJog;
	DrsSet			stSet;
	unsigned char	ucId;
}DrsSJog;

typedef struct DrsIJogData
{
	DrsIJog			stIJog[CMD_I_JOG_MAX_DRS];
}DrsIJogData;

typedef struct DrsSJogData
{
	unsigned char	ucPlayTime;
	DrsSJog			stSJog[CMD_S_JOG_MAX_DRS];
}DrsSJogData;

typedef struct DrsRWData
{
	unsigned char	ucAddress;
	unsigned char	ucLen;        
	unsigned char	ucData[MAX_DATA_SIZE-2];
}DrsRWData;

typedef union DrsData
{
	unsigned char	ucData[MAX_PACKET_SIZE-MIN_PACKET_SIZE];
	
	DrsRWData		stRWData;
	DrsIJogData		stIJogData;
	DrsSJogData		stSJogData;
}DrsData;

typedef struct
{
	unsigned char			ucHeader[2];
	unsigned char			ucPacketSize;
	unsigned char			ucChipID;
	unsigned char			ucCmd;
	unsigned char			ucCheckSum1;
	unsigned char			ucCheckSum2;
	DrsData					unData;
}DrsPacket;

//////////////////////////////수신 상태 결과 값//////////////////////////////
enum{
	DRS_RXWAITING,
	DRS_RXCOMPLETE,
	DRS_HEADERNOTFOUND,
	DRS_INVALIDSIZE,
	DRS_UNKNOWNCMD,
	DRS_INVALIDID,
	DRS_CHKSUMERROR,
	DRS_RXTIMEOUT
}DrsRxStatus;

#ifdef __HERKULEX_C
	#define HERKULEX_EXT
#else
	#define HERKULEX_EXT extern
#endif

//HerkuleX를 제어하기 위해 초기화하는 함수
HERKULEX_EXT void hklx_Init(unsigned long ulBaudRate);
//HerkuleX로 패킷을 보내는 함수
HERKULEX_EXT void hklx_SendPacket(DrsPacket stPacket);
//HerkuleX로부터 패킷을 받는 함수
HERKULEX_EXT unsigned char hklx_ucReceivePacket(DrsPacket *pstPacket);

#endif /* HERKULEX_H_ */